package com.dxc.user.validator;

import com.dxc.user.service.validator.EmailValidator;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class EmailValidatorTest {
    private static final boolean RESULT = true;
    private static final boolean RESULT1 = false;
    private static final String email = "name123";

    @Mock
    EmailValidator emailValidator;

    @Test
    public void validateEmailTest(String email){
        boolean r = false;
        when(emailValidator.validateEmail(email)).thenReturn(r);
        Assert.assertEquals(RESULT,r );
    };


}
